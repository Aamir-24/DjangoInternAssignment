from django.contrib import admin
from django.urls import path,include
from api.views import ClinetViewSet,ArtistViewSet,WorktViewSet
from rest_framework import routers

router = routers.DefaultRouter()
router.register(r'client',ClinetViewSet)
router.register(r'Artist',ArtistViewSet)
router.register(r'work',WorktViewSet)

urlpatterns = [
    path('',include(router.urls))
]