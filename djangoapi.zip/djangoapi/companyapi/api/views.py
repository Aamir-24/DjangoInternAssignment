from django.shortcuts import render
from rest_framework import viewsets
from api.models import Client,Artist,Work
from api.serializers import ClientSerializer,ArtistSerializer,WorkSerializer

class ClinetViewSet(viewsets.ModelViewSet):
    queryset = Client.objects.all()
    serializer_class = ClientSerializer


class ArtistViewSet(viewsets.ModelViewSet):
    queryset = Artist.objects.all()
    serializer_class = ArtistSerializer

class WorktViewSet(viewsets.ModelViewSet):
    queryset = Work.objects.all()
    serializer_class = WorkSerializer

