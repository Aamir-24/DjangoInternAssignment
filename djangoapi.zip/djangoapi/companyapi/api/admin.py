from django.contrib import admin

# Register your models here.
from api.models import Client,Artist,Work


admin.site.register(Client)
admin.site.register(Artist)
admin.site.register(Work)
