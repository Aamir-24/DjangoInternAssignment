from django.http import HttpResponse,JsonResponse
def home_page(request):
    print("home page request")
    lists = [
        'client',
        'Artist',
        'work'
    ]
    return JsonResponse(lists,safe=False)
